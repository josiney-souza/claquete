#! /bin/bash

# This file is part of Claquete.

# Claquete is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# Claquete is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Claquete.  If not, see <https://www.gnu.org/licenses/>

###############################################
##### Variaveis globais e de configuracao #####
###############################################
DADOS="dados.txt"
DADOS_INSCRICOES="dados-inscricoes.csv"
DADOS_OUVINTES="dados-ouvintes.csv"
DADOS_PALESTRANTES="dados-palestrantes.csv"
DADOS_MEDIADORES="dados-mediadores.csv"
DADOS_ORGANIZACAO="dados-organizacao.csv"
EVENTO="III Semana Acadêmica de Informática do Instituto Federal \
Catarinense - Campus Brusque"
PERIODO="25\/10\/2017 a 27\/10\/2017"
DATA=$(date +"%d de %B de %Y")
BASE_OUVINTE="base-ouvinte.tex"
BASE_PALESTRANTE="base-palestrante.tex"
BASE_MEDIADOR="base-mediador.tex"
BASE_ORGANIZACAO="base-organizacao.tex"
DIR_FONTES_TEX="fontes-tex"
DIR_CERTIFICADOS_PDF="certificados-pdf"
CONF_COR="black"



########################################
##### FUNCAO: cria_base_ouvintes() #####
########################################
function cria_base_ouvintes () {
    echo -n "Criando base de dados de ouvintes a partir das inscricoes... "

    rm -f ${DADOS_OUVINTES}
    cat ${DADOS_INSCRICOES} | while read PARTICIPANTE
    do
        EMAIL=$(echo $PARTICIPANTE | cut -d';' -f2)
        NOME=$(echo $PARTICIPANTE | cut -d';' -f3)
        CPF=$(echo $PARTICIPANTE | cut -d';' -f4)

    echo "${NOME};${CPF};ouvinte;24;${EMAIL}" >> ${DADOS_OUVINTES}
    done

    sleep 1s
    echo "OK."
}



#########################################
##### FUNCAO: cria_base_formatada() #####
#########################################
function cria_base_formatada () {
    echo -n "Criando base de dados formatada para o script... "

    rm -f ${DADOS}
    for BASE_USADA in ${DADOS_OUVINTES} ${DADOS_PALESTRANTES} \
        ${DADOS_MEDIADORES} ${DADOS_ORGANIZACAO}
    do
            cat ${BASE_USADA} | while read PARTICIPANTE
            do
                NOME=$(echo $PARTICIPANTE | cut -d';' -f1)
                CPF=$(echo $PARTICIPANTE | cut -d';' -f2)
                TIPO=$(echo $PARTICIPANTE | cut -d';' -f3)
                HORAS=$(echo $PARTICIPANTE | cut -d';' -f4)
                ADICIONAL=$(echo $PARTICIPANTE | cut -d';' -f6)

            echo "${NOME};${CPF};${TIPO};${HORAS};${ADICIONAL}" >> ${DADOS}
            done
    done

    sleep 1s
    echo "OK."
}



#####################################
##### FUNCAO: cria_fontes_tex() #####
#####################################
function cria_fontes_tex () {
    echo -n "Criando todos os fontes do tipo .TEX... "

    CONTADOR_AMBIGUIDADE=0
    cat ${DADOS} | while read PARTICIPANTE
    do
        NOME=$(echo $PARTICIPANTE | cut -d';' -f1)
        CPF=$(echo $PARTICIPANTE | cut -d';' -f2)
        TIPO=$(echo $PARTICIPANTE | cut -d';' -f3)
        HORAS=$(echo $PARTICIPANTE | cut -d';' -f4)
        ADICIONAL=$(echo $PARTICIPANTE | cut -d';' -f5)
        NOME_COM_UNDERLINE=$(echo $NOME | sed -e "s/ /_/g")
        NOME_ARQUIVO="certificado-${NOME_COM_UNDERLINE}-${TIPO}"

        if [ -e ${DIR_FONTES_TEX}/${NOME_ARQUIVO}.tex ]
        then
            cd ${DIR_FONTES_TEX}
            NOME_ARQUIVO=$(ls -1 ${NOME_ARQUIVO}*.tex | sort -t- -k 4 | \
                tail -n 1 | cut -d'.' -f1)
            NUM_CERTIFICADO=$(echo ${NOME_ARQUIVO} | cut -d'-' -f4)
            if [[ ${NUM_CERTIFICADO} == "" ]]
            then
                NUM_CERTIFICADO=1
            else
                ((NUM_CERTIFICADO = ${NUM_CERTIFICADO} + 1))
            fi
NOME_ARQUIVO="certificado-${NOME_COM_UNDERLINE}-${TIPO}-${NUM_CERTIFICADO}"
            cd - &> /dev/null
        fi

        if [[ ${TIPO} == "ouvinte" ]]
        then
            cp ${BASE_OUVINTE} ${NOME_ARQUIVO}.tex
        elif [[ ${TIPO} == "palestrante" ]]
        then
            cp ${BASE_PALESTRANTE} ${NOME_ARQUIVO}.tex
            sed -i -e "s/TITULOP/${ADICIONAL}/g" ${NOME_ARQUIVO}.tex
        elif [[ ${TIPO} == "mediador" ]]
        then
            cp ${BASE_MEDIADOR} ${NOME_ARQUIVO}.tex
            sed -i -e "s/ASSUNTOP/${ADICIONAL}/g" ${NOME_ARQUIVO}.tex
        elif [[ ${TIPO} == "organizacao" ]]
        then
            TIPO="membro da Comissão de Organização"
            cp ${BASE_ORGANIZACAO} ${NOME_ARQUIVO}.tex
            sed -i -e "s/ATIVIDADESP/organizador/g" ${NOME_ARQUIVO}.tex
        else
            echo "ERRO: tipo de participante nao existe"
            exit 1
        fi

        sed -i -e "s/NOMEP/${NOME}/g" -e "s/CPFP/${CPF}/g" \
            -e "s/EVENTOP/${EVENTO}/g" -e "s/PERIODOP/${PERIODO}/g" \
            -e "s/TIPOP/${TIPO}/g" -e "s/HORASP/${HORAS}/g" \
            -e "s/DATAP/${DATA}/g" ${NOME_ARQUIVO}.tex

        sed -i -e "s/CONF_COR/${CONF_COR}/g" ${NOME_ARQUIVO}.tex

        mv ${NOME_ARQUIVO}.tex ${DIR_FONTES_TEX}
    done

    sleep 1s
    echo "OK."
}



#######################################
##### FUNCAO: cria_certificados() #####
#######################################
function cria_certificados () {
    echo -n "Criando todos os certificados em .PDF... "

    cd ${DIR_FONTES_TEX}
    for FONTE in $(ls)
    do
        pdflatex -output-directory ../${DIR_CERTIFICADOS_PDF} ${FONTE} &> /dev/null
        pdflatex -output-directory ../${DIR_CERTIFICADOS_PDF} ${FONTE} &> /dev/null
    done
    cd - &> /dev/null
    rm -f ${DIR_CERTIFICADOS_PDF}/*.{aux,log}

    sleep 1s
    echo "OK."
}



############################
##### FUNCAO PRINCIPAL #####
############################
if [[ $1 == "-rm" ]]
then
    if [[ $2 == "tex" ]]
    then
        cd ${DIR_FONTES_TEX} && rm -f ./* && cd - &> /dev/null
    elif [[ $2 == "pdf" ]]
    then
        cd ${DIR_CERTIFICADOS_PDF} && rm -f ./* && cd - &> /dev/null
    else
        cd ${DIR_FONTES_TEX} && rm -f ./* && cd - &> /dev/null
        cd ${DIR_CERTIFICADOS_PDF} && rm -f ./* && cd - &> /dev/null
    fi
else
    cd ${DIR_FONTES_TEX} && rm -f ./* && cd - &> /dev/null
    cd ${DIR_CERTIFICADOS_PDF} && rm -f ./* && cd - &> /dev/null
    cria_base_ouvintes
    cria_base_formatada
    cria_fontes_tex
    cria_certificados
fi

exit 0
